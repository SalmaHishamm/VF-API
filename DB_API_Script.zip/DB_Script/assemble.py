
import cx_Oracle
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr #3ashan yaban salma hisham msh el mail
from flask import Flask, request, jsonify
import requests
import jwt



alarm_count=3

global token

connection = cx_Oracle.connect('system/12345@localhost:1521/xe')

cursor=connection.cursor()

cursor.execute('SELECT COUNT(*) FROM students')
#rows = cursor.fetchall()
count = cursor.fetchone()[0]
print(count)

# Sender's email address and password
sender_email = "salmahesham60@gmail.com"
sender_name="Salma Hisham"
password = "rjnkzyokivtspvxt"

# Recipient's email address
recipient_email = ["salmahesham60@gmail.com"]

# Create the email message
subject = "The system status is in danger!"

text = 'Hello this mail sent from python'

html = """\
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warning</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f8e1e1;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .warning-container {
            background-color: #f44336;
            color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        h1 {
            margin: 0;
            font-size: 30px;
        }
        p {
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="warning-container">
        <h1>Warning!</h1>
       
        <p>The number of records has exceeded the limit</p>
    </div>
</body>
</html>
"""

msg = MIMEMultipart("alternative") #alternative de khalteny html file maykonsh attachment
#msg['From'] = sender_email
msg['From'] = formataddr((sender_name,sender_email))
msg['To'] = ', '.join(recipient_email)
msg['Subject'] = subject

part1=MIMEText(text, 'plain')
part2=MIMEText(html, 'html')

msg.attach(part1)
msg.attach(part2)




# Connect to the SMTP server and send the email
smtp_server = "smtp.gmail.com"  # Replace with your SMTP server address
smtp_port = 587  # Replace with your SMTP server port (usually 587 for TLS)


# if (count>=alarm_count):
#  try :
#   with smtplib.SMTP(smtp_server, smtp_port) as server:
#     server.starttls()
#     server.login(sender_email, password)
   
#     #server.sendmail(sender_email, recipient_email, msg.as_string())

#  except Exception as e:
#     print(e)
    
# else :
#     print("The status is safe")


    
    
app = Flask(__name__)

# token="ss"
# def Authenticate ():
#   url = "http://127.0.0.1:5000/api/token"
#   print(token)
#   headers = {"Authorization": "Bearer {}".format(token)}

#   response = requests.get(url, headers=headers)

#   if response.status_code == 200:
#     print("Successfully authenticated with the API")
#     return True
#   else:
#     print("Failed to authenticate with the API") 
#     return False  

@app.route('/api/hello', methods=['GET'])
def hello():
    return jsonify(message='Hello, World!')


@app.route('/api/add', methods=['POST'])
def add():
    data = request.get_json()
    if 'a' in data and 'b' in data:
        result = data['a'] + data['b']
        return jsonify(result=result)
    else:
        return jsonify(error='Invalid input')
    
    
@app.route('/api/send', methods=['GET'])
def send():
 data = request.get_json()

 #print(count>=alarm_count and Authenticate()==True)
 if (count>=alarm_count ):
    
    try :
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, password)
   
            server.sendmail(sender_email, data['email'], msg.as_string())
            # print(data['name'])
            # print(data)

    except Exception as e:
        print(e)
    
 else :
   
    print("The status is safe")
        
        
 return jsonify(message='Hello, World!')


# @app.route('/api/token', methods=['POST'])
# def sendToken():
 
 
#  secret_key = "my-secret-key"

#  payload = {
#   "sub": "1234567890",
#   "name": "John Doe"
#  }

#  token = jwt.encode(payload, secret_key, algorithm="HS256")

#  return jsonify(message=token)
 
#  url = "http://127.0.0.1:5000/api/token"

#  #token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"

#  headers = {"Authorization": "Bearer {}".format(token)}

#  response = requests.post(url, headers=headers)

#  if response.status_code == 200:
#   print("Successfully authenticated with the API")
#  else:
#   print("Failed to authenticate with the API")
        
        
 
    
    
    


#from requests.auth import HTTPBasicAuth
  
# Making a get request
# response = requests.get('https://api.github.com / user, ',
#             auth = HTTPBasicAuth('user', 'pass'))
  
# # print request object
# print(response)

# import jwt

# secret_key = 'my-secret-key'

# payload = {
#   'sub': '1234567890',
#   'name': 'John Doe',
# }

# token = jwt.encode(payload, secret_key, algorithm='HS256')
# print(token)


if __name__ == '__main__':
    app.run(debug=True)
    
    
    




   
